UPDATE sourcedb.cdc_src_member SET location = 'Hyd' WHERE driverid >= 10;

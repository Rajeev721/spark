create database sourcedb;
DROP IF EXISTS sourcedb.cdc_src_member;
CREATE TABLE sourcedb.cdc_src_member (driverid int primary key, name VARCHAR(20),
ssn varchar(30), location varchar(30), tim varchar(30));
LOAD DATA LOCAL INFILE 'source_data_scd1.csv' INTO TABLE sourcedb.cdc_src_member
FIELDS TERMINATED BY ',' ignore 1 lines;
#!/usr/local/bin/python2.7

import sys
import os
import commands
import time
import re
from xml.dom import minidom

''' Function to read the configuration file present in xml format '''

def xml_read(param):
	conf = param
	doc = minidom.parse(conf)
	sources = doc.getElementsByTagName("sysrec")
	aList = []
	for source in sources:
		system_id = source.getAttribute("code")
		if system_id == "sqoop":
			connection_url = source.getElementsByTagName("connection_url")[0]
			aList.append(connection_url.firstChild.data)
			credentials_path = source.getElementsByTagName("credentials_path")[0]
			aList.append(credentials_path.firstChild.data)
			field_delimiter = source.getElementsByTagName("field_delimiter")[0]
			aList.append(field_delimiter.firstChild.data)
			source_table = source.getElementsByTagName("source_table")[0]
			aList.append(source_table.firstChild.data)
			source_db = source.getElementsByTagName("source_db")[0]
			aList.append(source_db.firstChild.data)
			hive_db = source.getElementsByTagName("hive_db")[0]
			aList.append(hive_db.firstChild.data)
			hive_staging_table = source.getElementsByTagName("hive_staging_table")[0]
			aList.append(hive_staging_table.firstChild.data)
			db_conn_id = source.getElementsByTagName("db_conn_id")[0]
			aList.append(db_conn_id.firstChild.data)
			hive_main_table = source.getElementsByTagName("hive_main_table")[0]
			aList.append(hive_main_table.firstChild.data)
			hive_script = source.getElementsByTagName("hive_script")[0]
			aList.append(hive_script.firstChild.data)
			log_path = source.getElementsByTagName("log_path")[0]
			aList.append(log_path.firstChild.data)
			return aList

''' Function to compare count between Source and Staging table and print if counts are not matching '''

def count_comaparision_hive_load(status,output,param,hive_db,hive_staging_table,hive_main_table,hive_script,log_path):
	log.write("Checking record count from Source and Staging table" + '\n')
	regex = re.compile('Retrieved ([0-9]*)')
	source_cnt = regex.findall(output)[0].strip()
	if status != 0 :
		log.write("Import job Status: Failed. Error while fetching Source count" + '\n')
		exit(1)
		log.close()
	cmd = "hive -S -e 'select count(*) from %s.%s;'" %(hive_db,hive_staging_table)
	status, output = commands.getstatusoutput(cmd)
	target_cnt = output.split('\n')[-3]
	if status != 0 :
		log.write("Error while fetching Staging Target count" + '\n')
		log.write("Import job Status: Failed. Error while fetching Staging Target count" + '\n')
		log.close()
		print output
		exit(1)
	if int(source_cnt) != int(target_cnt):
		log.write("Source and Staging Target count not matching" + '\n')
		log.close()
		exit(1)

	else:
		log.write("Source count and Staging table count are matching, hence starting data load into Target table" + '\n')
		cmd = "hive -f %s" %(hive_script)
		status, output = commands.getstatusoutput(cmd)
		if status != 0 :
			log.write("Failed loading data to Target table from Staging table." + '\n')
			log.close()
		else:
			log.write("Succesfully loaded data into Target table" + '\n')
			log.write("*****************************************************************************************************" + '\n')
			log.close()

''' Function to truncate and load the Staging table using sqoop, status would be the message from command line which shows if there was any error or not for the sqoop import'''

def truncate_load(param,connection_url,credentials_path,field_delimiter,source_table,source_db,hive_db,hive_staging_table,username,password,log_path):
	log.write("Starting Sqoop import job" + '\n')
	cmd = "sqoop import --connect %s//%s:%s/%s --username %s -password %s --table %s --fields-terminated-by '%s' --hive-import --hive-overwrite --hive-table %s.%s "%(connection_url,servername,port,dbname,username,password,source_table,field_delimiter,hive_db,hive_staging_table)
	status, output = commands.getstatusoutput(cmd)
	if status != 0 :
		log.write("Import job Status: Failed. Error in executing Sqoop job" + '\n')
		log.close()
		print output
		exit(1)
	else :
		log.write("Successfully imported data to Staging table" + '\n')
	return status,output
''' Main function to read the configuration file which has all the connection details and also assigning parameters for them'''
if __name__ == "__main__":
	param = sys.argv[1]
	aList = xml_read(param)
	connection_url = str(aList[0])
	credentials_path = str(aList[1])
	field_delimiter = str(aList[2])
	source_table = str(aList[3])
	source_db = str(aList[4])
	hive_db = str(aList[5])
	hive_staging_table = str(aList[6]).lower()
	db_conn_id = str(aList[7])
	hive_main_table = str(aList[8]).lower()
	hive_script = str(aList[9])
	log_path = str(aList[10])
	timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
	timestamp1 = time.strftime("%Y_%m_%d_%H_%M_%S")
	log_path = "%s%s_%s.log" %(log_path,hive_main_table,timestamp1)
	a = []
	cmd = " awk '/%s/' " %(db_conn_id) + credentials_path
	status, output = commands.getstatusoutput(cmd)
	if status != 0 :
		print output
		exit(1)
	elif output.split('|')[0] == db_conn_id :
		servername = output.split('|')[1]
		dbname = output.split('|')[2]
		port = output.split('|')[3]
		username = output.split('|')[4]
		password = output.split('|')[5]
	else:
		log.write("Invalid servername" + '\n')
		exit(1)
	log = open(log_path, 'wb')
	log.write("#####################################################################################################" + '\n')
	log.write("SCD run date : " + str(timestamp) + '\n')
	log.write("Completed reading XML file" + '\n')
	status,output = truncate_load(param,connection_url,credentials_path,field_delimiter,source_table,source_db,hive_db,hive_staging_table,username,password,log_path)
	if status != 0 :
		print output
		exit(1)
	else:
		count_comaparision_hive_load(status,output,param,hive_db,hive_staging_table,hive_main_table,hive_script,log_path)


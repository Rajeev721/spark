UPDATE sourcedb.scd2_src_member
SET location = 'Hyd',
action_indicator = 'UPDATE' WHERE driverid = 10;
UPDATE sourcedb.scd2_src_member
SET location = 'Hyd',
action_indicator = 'DELETE' WHERE driverid >40;
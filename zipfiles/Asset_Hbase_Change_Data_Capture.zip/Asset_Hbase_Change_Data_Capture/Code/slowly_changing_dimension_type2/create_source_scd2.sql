DROP TABLE IF EXISTS sourcedb.scd2_src_member;
CREATE TABLE sourcedb.scd2_src_member (driverid int primary key, name VARCHAR(20),
ssn varchar(30), location varchar(30), tim varchar(30), action_indicator varchar(30),strtdate varchar(30),endate varchar(30));
LOAD DATA LOCAL INFILE 'source_data_scd2.csv' INTO TABLE sourcedb.scd2_src_member
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r\n' ignore 1 lines;

source ./param_file.txt
###########################################################################################################################
##      Title       : Common_extract_framework                      										      #
##      Author      : Hari Hara Nandan ##	
##      Associates  : Suvrat Dharmadikari, Sumit Deshmukh, Ramu Tuniki																          	      # 
##		Description : Intial validation and Data fetch from tables  #
##      Date		: 8/4/2017	
##      sample input: sh file_nm.sh $(INTRFC_NAME) $(RPT_NAME)																				          #
##      Version 1.0 : Initial Version																			          #
###########################################################################################################################


# Inputing the values #

SCHEMA_NAME=$SCHEMA_NAME
LOG_DIR=$LOGFILE_PATH	
REPORTS=$REPORTS	
#echo "LOG_DIR = " $LOG_DIR
REPORT_NAME=$2;
echo "report name is $REPORT_NAME"
INTERFACE_NAME=$1;
echo "interface name is $INTERFACE_NAME" 


# Creating log file #
File_time=$(date +'%Y-%m-%d')
start_date_time=$( date +'%Y-%m-%d %H:%M:%S')
LOG_TIMESTAMP=$( date +'%Y%m%d%H%M%S')
Audit_time=$( date +'%Y%m%d%H%M%S')
logfile=$LOG_DIR/"${REPORT_NAME}_${LOG_TIMESTAMP}".log
	echo "------LOG_FILE =$logfile-----"

	exec 2> $logfile 1>&2

      echo "start time stamp:$start_date_time"
if [[ $# -ne 2 ]]                           ##checks whether two parameters are passed as input or not
 then
    echo "------ERROR : Expecting two parameters INTERFACE_NAME  REPORT_NAME------- "
    exit 1
fi


#Validating REPORT_NAME and INTERFACE_NAME by taking their COUNT,Fetching REPORT_ID and INTERFACE_ID#

 hive -e "use ${SCHEMA_NAME}; select  CONCAT('INTERFACE_DET=',Q.INTERFACE_ID),CONCAT('REPORT_DET=',P.REPORT_ID) from EXTR_INTERFACE Q join EXTR_REPORT P on(Q.INTERFACE_ID=P.INTERFACE_ID) where Q.INTERFACE_NAME='$INTERFACE_NAME' and P.REPORT_NAME='$REPORT_NAME';select  CONCAT('INTERFACE_DET_COUNT=',COUNT(DISTINCT(Q.INTERFACE_ID))),CONCAT('REPORT_DET_COUNT=',COUNT(DISTINCT(P.REPORT_ID))) from EXTR_INTERFACE Q join EXTR_REPORT P on(Q.INTERFACE_ID=P.INTERFACE_ID) where Q.INTERFACE_NAME='$INTERFACE_NAME' and P.REPORT_NAME='$REPORT_NAME';"| sed 's/^WARN.*//g' | sed 's/\t/\n/g'

stat1=$?
 
echo "stat1:$stat1"


 if [[ ! "$stat1" =~ "0" ]]; then
		 echo "------------ERROR : Failed in executing hive query call for validating REPORT_NAME and INTERFACE_NAME--------------- " 
		exit 1
fi
		echo "-----INFO: Hive query execution is successful,proceeding with validation of REPORT_NAME and INTERFACE_NAME.`date`---------------------- " 


# Storing COUNT of REPORT_ID and INTERFACE_ID in variables

INTERFACE_DET_COUNT=$(grep 'INTERFACE_DET_COUNT=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')
REPORT_DET_COUNT=$(grep 'REPORT_DET_COUNT=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')

##Validating REPORT_NAME and INTERFACE_NAME

if [[ $INTERFACE_DET_COUNT == 1 && $REPORT_DET_COUNT == 1 ]] 
then
	echo "INFO : REPORT_NAME and INTERFACE_NAME are valid, Hence proceeding..."
else
	echo "ERROR : REPORT_NAME and INTERFACE_NAME are Invalid, process exiting.."
	exit 1
fi


# Storing  REPORT_ID and INTERFACE_ID in variables

RPT_ID=$(grep 'REPORT_DET=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')
INTRFC_ID=$(grep 'INTERFACE_DET=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')




#Checks whether the input passed is valid or not by validating relationship among required tables

#Joins required table to fetch data for processing

#Fetch data form column format table

hive -e "use ${SCHEMA_NAME};select CONCAT('INTRFC_ID_COUNT_TBL1=',COUNT(DISTINCT(a.INTERFACE_ID))), 
CONCAT('INTRFC_ID_COUNT_TBL2=',COUNT(DISTINCT(b.INTERFACE_ID))),
CONCAT('RPT_ID_COUNT_TBL2=',COUNT(DISTINCT(b.REPORT_ID))),
CONCAT('INTRFC_ID_COUNT_TBL3=',COUNT(DISTINCT(c.INTERFACE_ID))),
CONCAT('TBL_ID_COUNT_TBL3=',COUNT(DISTINCT(c.TABLE_ID))),
CONCAT('TBL_ID_COUNT_TBL4=',COUNT(DISTINCT(d.TABLE_ID)))
from EXTR_INTERFACE a
join EXTR_REPORT b on (a.INTERFACE_ID=b.INTERFACE_ID)
join EXTR_TABLE c on (b.INTERFACE_ID=c.INTERFACE_ID)
join EXTR_COLUMN d on (c.TABLE_ID=d.TABLE_ID)
where b.REPORT_ID=$RPT_ID and a.INTERFACE_ID=$INTRFC_ID and c.INTERFACE_ID=$INTRFC_ID;select concat('RPT_ID=',b.REPORT_ID),
concat('colm_ref=',b.column_ref),
concat('rpt_nm=',b.report_name),
concat('rpt_dsc=',b.report_desc),
concat('file_nm=',b.file_name),
concat('file_type=',b.file_type),
concat('file_pth=',b.file_path),
concat('dlmtr_val=',b.DELIMITER),
concat('colm_having?',b.column_having),
concat('colm_ordr=',b.column_order),
concat('colm_grp=',b.column_group),
concat('fltr_val?',b.filter),
concat('TBL_ID=',c.TABLE_ID),
concat('table_name=',c.table_name)
from EXTR_REPORT b
join EXTR_TABLE c 
on (b.INTERFACE_ID=c.INTERFACE_ID)  
where b.REPORT_ID=$RPT_ID and b.INTERFACE_ID=$INTRFC_ID;select concat('columnids=',column_id),concat('formatvalues?',COLUMN_FORMAT),concat('business=',BUSNS_COLUMN_NAME) from EXTR_COLUMN_FORMAT where REPORT_ID=$RPT_ID;"| sed 's/^WARN.*//g' | sed 's/\t/\n/g'		

stat2=$?

echo "stat2:$stat2"
if [[ ! "$stat2" =~ "0" ]]; then
		 echo "------------ERROR : Failed in executing hive query to fetch data from required tables--------------- " 
		exit 1
fi
		echo "----------- INFO: Initial Data fetch from all the tables is completed successfully `date` ------------"
		

#Store all the  validation fetched data into variables and determine relationship#

INTRFC_ID_COUNT_TBL1=$(grep 'INTRFC_ID_COUNT_TBL1=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')
INTRFC_ID_COUNT_TBL2=$(grep 'INTRFC_ID_COUNT_TBL2=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')
RPT_ID_COUNT_TBL2=$(grep 'RPT_ID_COUNT_TBL2=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')
INTRFC_ID_COUNT_TBL3=$(grep 'INTRFC_ID_COUNT_TBL3=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')
TBL_ID_COUNT_TBL3=$(grep 'TBL_ID_COUNT_TBL3=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')
TBL_ID_COUNT_TBL4=$(grep 'TBL_ID_COUNT_TBL4=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')


if [[ $INTRFC_ID_COUNT_TBL1 == 1 && $INTRFC_ID_COUNT_TBL2 == 1 && $RPT_ID_COUNT_TBL2 == 1 && $INTRFC_ID_COUNT_TBL3 && $TBL_ID_COUNT_TBL3 == 1 && $TBL_ID_COUNT_TBL4 == 1 ]]
then
	echo "INFO : Relation exists among all required tables, process starting......"
else
	echo "ERROR : NO RELATION BETWEEN TABLES PLEASE CORRECT TABLE ENTRIES AND TRY AGAIN LATER"
	exit 1
fi


#Store  framework table data into variables

		
file_nm=$(grep -i 'file_nm=' ${logfile} | cut -f 2 -d '=' )
file_nm="$file_nm"
echo "-----------$file_nm---------"

file_pth=$(grep -i 'file_pth=' ${logfile} | cut -f 2 -d '=') 
echo "----------$file_pth---------------"
		
RPT_ID=$(grep -i 'RPT_ID=' ${logfile} | cut -f 2 -d '=' )
echo "----------$RPT_ID---------------"

TBL_ID=$(grep -i 'TBL_ID=' ${logfile} | cut -f 2 -d '=' )
echo "--------------$TBL_ID---------------------"

dlmtr_val=$(grep -i 'dlmtr_val=' ${logfile} | cut -f 2 -d '=' | sed 's/"//g')
echo "----------$dlmtr_val-----------------"

file_type=$(grep -i 'file_type=' ${logfile} | cut -f 2 -d '=' | sed 's/"//g')

report_desc=$(grep -i 'rpt_dsc=' ${logfile} | cut -f 2 -d '=' )
echo "----------$report_desc-----------------"

path="$file_pth/${file_nm}_${LOG_TIMESTAMP}"
echo "----$path-----"

colval=$(grep 'colm_ref=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//') 
echo "----------column val is : $colval--------------------"



#################################################################################
#This script does processing on EXTR_COLUMN_FORMAT table#
#################################################################################
#Intialization of variables which can be used in processing column format

	   
var='';
ID=0;
FRMT_VALUE=''
variable_val=''
busns_val=0;
count=0;
column_details=0;
colm_id=0;
colm_ref=0;
format='';
column_name=0;
String=0;
var_result='';
format_result='';
busns_value='';
busns=''
columnids_val_del=''
formatvalues_val_del=''
variables_val_del=''
business_val_del=''
columnids_val=''
formatvalues_val=''
variables_val=''
business_val=''
query='';
columnids_count=0;
comb='';
transpose='';
q1='';
ID=''
q2=''
iterator=0;
I=''

echo "===========Getting colm_id from table============"

## Storing fetched values of column_format table details into variables



			
columnids_val_del=$(grep -i "columnids=" ${logfile} | cut -f 2 -d '=' | tr '\n' ',' | sed 's/,$//')
echo "columnids_val_del is $columnids_val_del"

formatvalues_val_del=$(grep -i "formatvalues?" ${logfile} | cut -f 2 -d '?' | tr '\n' ',' | sed 's/,$//')
echo "formatvalues_val_del is $formatvalues_val_del"
				
business_val_del=$(grep -i "business=" ${logfile} | cut -f 2 -d '=' | tr '\n' ',' | sed 's/,$//')
echo "business_val_del is $business_val_del"

columnids_count=$(echo $columnids_val_del | tr ',' '\n' | wc -l)
echo "columnids_count is $columnids_count"
		

#validate whether column_ids are present or not and process the values 

	   
		
		
if [[ ! -z $columnids_val_del &&  ! "$file_type" =~ "delimiter" ]]
then
	echo "entered fixed length block"
	for((i=1;i<=$columnids_count;i++));
	do
		columnids_val=$(echo "$columnids_val_del" | cut -f $i -d ',')
        echo "columnids_val is $columnids_val"
	
		formatvalues_val=$(echo "$formatvalues_val_del" | cut -f $i -d ',')
        echo "format_$i=$columnids_val?$formatvalues_val"
			
		business_val=$(echo "$business_val_del" | cut -f $i -d ',')
        if [[ ! -z $business_val ]]
		then
			echo "busns_$i=$business_val"
			query="$query;use ${SCHEMA_NAME};select CONCAT('columnlength_$i=',COLUMN_LENGTH) from EXTR_COLUMN where column_id=$columnids_val and table_id=$TBL_ID"
		else
			echo "else block $i"
			query="$query;use ${SCHEMA_NAME};use ${SCHEMA_NAME};select CONCAT('busns_$i=',BUSNS_COLUMN_NAME) from EXTR_COLUMN where column_id=$columnids_val and table_id=$TBL_ID;select CONCAT('columnlength_$i=',COLUMN_LENGTH) from EXTR_COLUMN where column_id=$columnids_val and table_id=$TBL_ID"
        fi
	done
	query=${query#?}
    query=$(echo $query | sed 's/;;/;/g')
    
elif [[ ! -z $columnids_val_del ]]
then
	for((i=1;i<=$columnids_count;i++));
	do
		columnids_val=$(echo "$columnids_val_del" | cut -f $i -d ',')
        echo "columnids_val is $columnids_val"
	
		formatvalues_val=$(echo "$formatvalues_val_del" | cut -f $i -d ',')
        echo "format_$i=$columnids_val?$formatvalues_val"
			
		business_val=$(echo "$business_val_del" | cut -f $i -d ',')
        if [[ ! -z $business_val ]]
		then
			echo "busns_$i=$business_val"
		else
			query="$query;use ${SCHEMA_NAME};select CONCAT('busns_$i=',BUSNS_COLUMN_NAME) from EXTR_COLUMN where column_id=$columnids_val and table_id=$TBL_ID"
		fi
	done   
	query=${query#?}
    query=$(echo $query | sed 's/;;/;/g')
      
else
	#comb="NA"
	echo "INFO : nothing to process  on EXTR_COLUMN_FORMAT"
fi

if [[ ! -z $query ]]
then
	hive -e "$query;" | sed 's/^WARN.*//g' 
	stat3=$?
	if [[ ! "$stat3" =~ "0" ]]; then
		echo "------------ERROR : Failed in fetching records required for column formatting--------------- " 
		exit 1
	fi       
fi
	echo "-----INFO: Data fetch is successful `date`---------------------- " 
	if [[ ! "$file_type" =~ "delimiter" ]]
	then
		for((i=1;i<=$columnids_count;i++))
		do
			formater=$(grep -i "format_$i=" ${logfile} | sed "s/format_$i=//" | cut -f $i -d ',' )
			business_col=$(grep -i "busns_$i=" ${logfile} | cut -f 2 -d '=' )
			columnlen=$(grep -i "columnlength_$i=" ${logfile} | cut -f 2 -d '=' )
			foo1=$(echo $formater |  cut -f 1 -d '?' )
			foo2=$(echo $formater |  cut -f 2 -d '?' )
			echo "business col is $business_col"
			#comb="$comb # $formater"
			comb="$comb#$foo1?cast($foo2 as char($columnlen))as $business_col"
			echo $comb
		done
		comb=$(echo $comb | sed 's/^#//')
		#echo "$comb"
		result=$comb
		echo "result is $result"
	else
		for((i=1;i<=$columnids_count;i++))
		do
			formater=$(grep -i "format_$i=" ${logfile} | sed "s/format_$i=//" | cut -f $i -d ',' )
			
			business_col=$(grep -i "busns_$i=" ${logfile} | cut -f 2 -d '=' )
			echo "business col is $business_col"
			#comb="$comb # $formater"
			comb="$comb#$formater as $business_col"
			echo $comb
		done
		comb=$(echo $comb | sed 's/^#//')
		#echo "$comb"
		result=$comb
		echo "result is $result"
	fi

	
#################################################################################
#Final processing which converts column-ids to name and does proper alignment#
#################################################################################


#Intializing variables 
								      
transpose='';
q1='';
ID=''
q2=''
iterator=0;
I=''
q3='';
q4='';
q5='';
q6='';
q7=''; 


transform="$comb"
coltransform=$(grep -i "colm_ref=" ${logfile} | cut -f 2 -d '=' )
filtertransform=$(grep -i "fltr_val?" ${logfile} | cut -f 2 -d '?' )
colhavingtransform=$(grep -i "colm_having?" ${logfile} | cut -f 2 -d '?' )
colgrptransform=$(grep -i "colm_grp=" ${logfile} | cut -f 2 -d '=' )
colordtransform=$(grep -i "colm_ordr=" ${logfile} | cut -f 2 -d '=' )
transform_count=$(grep -o "?"  <<< $transform |  wc -l )                   

IFS="#" read -a transform_array<<<"$transform"                                       
formatter=$(echo "$transform" | grep -oP '[0-9]+(?=[?])')
format_array=( $formatter )

coltransform_extract=$(echo "$coltransform" | egrep -o -E '[0-9]{1,10}')
filtertransform_extract=$(echo "$filtertransform" | egrep -o -E '[0-9]{1,10}')
colgrptransform_extract=$(echo "$colgrptransform" | egrep -o -E '[0-9]{1,10}')
colhavingtransform_extract=$(echo "$colhavingtransform" | egrep -o -E '[0-9]{1,10}')
colordtransform_extract=$(echo "$colordtransform" | egrep -o -E '[0-9]{1,10}')

extractor=$(echo "$transform" | sed 's/[0-9]*?//g')
extract=$(echo "$extractor" | egrep -o -E '[0-9]{1,10}')
count=$(echo "$extract"|wc -w)


#Fetching and storing Count of Numbers which can be replaced with column names

coltransform_count=$(echo "$coltransform_extract"|wc -w)
filtertransform_count=$(echo "$filtertransform_extract"|wc -w)
colgrptransform_count=$(echo "$colgrptransform_extract"|wc -w)
colhavingtransform_count=$(echo "$colhavingtransform_extract"|wc -w)
colordtransform_count=$(echo "$colordtransform_extract"|wc -w)
extract=$(echo "$extract" | tr '\n' ','| sed 's/,*$//')
coltransform_extract=$(echo "$coltransform_extract" | tr '\n' ','| sed 's/,*$//')
filtertransform_extract=$(echo "$filtertransform_extract" | tr '\n' ','| sed 's/,*$//')
colgrptransform_extract=$(echo "$colgrptransform_extract" | tr '\n' ','| sed 's/,*$//')
colhavingtransform_extract=$(echo "$colhavingtransform_extract" | tr '\n' ','| sed 's/,*$//')
colordtransform_extract=$(echo "$colordtransform_extract" | tr '\n' ','| sed 's/,*$//')


#Storing the values(Numbers) into arrays
 	
IFS=',' read -a IDS<<<"$extract"
IFS=',' read -a IDS_col<<<"$coltransform_extract"
IFS=',' read -a IDS_filter<<<"$filtertransform_extract"
IFS=',' read -a IDS_grp<<<"$colgrptransform_extract"
IFS=',' read -a IDS_hav<<<"$colhavingtransform_extract"
IFS=',' read -a IDS_ord<<<"$colordtransform_extract"


#Validating whether Format has data and and building a query
#storing column names in a String variable using concat and passed iterator as reference Eg: CONCAT('COLO_$i=',COLUMN_NAME) here i=0,1,2,3.....
                                 
if [[ ! -z $transform ]]
then
	for((i=0;i<$count;i++));
    do
		q2="$q2;select CONCAT('COLO_$i=',COLUMN_NAME) from EXTR_COLUMN where column_id=${IDS[$i]} and table_id=$TBL_ID"
    done
    q2=${q2#?}
    q2=$(echo $q2 | sed 's/;;/;/g')
    q2="use ${SCHEMA_NAME};$q2"  
fi
	

#Building a query for Column reference
#storing column names in a String variable using concat and passed iterator as reference Eg: CONCAT('COLO_$i=',COLUMN_NAME) here i=0,1,2,3.....
if [[ ! "$file_type" =~ "delimiter" ]]
then                   	
	for((i=0;i<$coltransform_count;i++));
	do
	q3="$q3;select CONCAT('COLT_$i=','cast','(',COLUMN_NAME,' as ','char','(',COLUMN_LENGTH,'))' ' as ',BUSNS_COLUMN_NAME) from EXTR_COLUMN where column_id=${IDS_col[$i]} and table_id=$TBL_ID"
	done
	q3=${q3#?}
	q3=$(echo $q3 | sed 's/;;/;/g')
	q3="use ${SCHEMA_NAME};$q3"
else
	for((i=0;i<$coltransform_count;i++));
	do
	q3="$q3;select CONCAT('COLT_$i=',COLUMN_NAME, ' as ',BUSNS_COLUMN_NAME) from EXTR_COLUMN where column_id=${IDS_col[$i]} and table_id=$TBL_ID"
	done
	q3=${q3#?}
	q3=$(echo $q3 | sed 's/;;/;/g')
	q3="use ${SCHEMA_NAME};$q3" 
fi								

#Validating whether Filter has data and and building a query
#storing column names in a String variable using concat and passed iterator as reference Eg: CONCAT('COLO_$i=',COLUMN_NAME) here i=0,1,2,3.....
								
if [[ ! -z $filtertransform ]]
then
    for((i=0;i<$filtertransform_count;i++));
	do
		q4="$q4;select CONCAT('COLF_$i=',COLUMN_NAME) from EXTR_COLUMN where column_id=${IDS_filter[$i]} and table_id=$TBL_ID"
    done
    q4=${q4#?}
    q4=$(echo $q4 | sed 's/;;/;/g')
    q4="use ${SCHEMA_NAME};$q4"  
fi
		

#Validating whether columnGroup has data and and building a query
#storing column names in a String variable using concat and passed iterator as reference Eg: CONCAT('COLO_$i=',COLUMN_NAME) here i=0,1,2,3.....
			
if [[ ! -z $colgrptransform ]]
then
	for((i=0;i<$colgrptransform_count;i++));
    do
		q5="$q5;select CONCAT('COLG_$i=',COLUMN_NAME) from EXTR_COLUMN where column_id=${IDS_grp[$i]} and table_id=$TBL_ID"
    done
    q5=${q5#?}
    q5=$(echo $q5 | sed 's/;;/;/g')
    q5="use ${SCHEMA_NAME};$q5"  
fi
	

#Validating whether columnHaving has data and and creating a query
#storing column names in a String variable using concat and passed iterator as reference Eg: CONCAT('COLO_$i=',COLUMN_NAME) here i=0,1,2,3.....

if [[ ! -z $colhavingtransform ]]
then
    for((i=0;i<$colhavingtransform_count;i++));
	do
		q6="$q6;select CONCAT('COLH_$i=',COLUMN_NAME) from EXTR_COLUMN where column_id=${IDS_hav[$i]} and table_id=$TBL_ID"
    done
    q6=${q6#?}
    q6=$(echo $q6 | sed 's/;;/;/g')
    q6="use ${SCHEMA_NAME};$q6"
fi


#Validating whether columnOrder has data and and creating a query
#storing column names in a String variable using concat and passed iterator as reference Eg: CONCAT('COLO_$i=',COLUMN_NAME) here i=0,1,2,3.....

if [[ ! -z $colordtransform ]]
then
	for((i=0;i<$colordtransform_count;i++));
    do
		q7="$q7;select CONCAT('COLRDE_$i=',COLUMN_NAME) from EXTR_COLUMN where column_id=${IDS_ord[$i]} and table_id=$TBL_ID"
    done
    q7=${q7#?}
    q7=$(echo $q7 | sed 's/;;/;/g')
    q7="use ${SCHEMA_NAME};$q7"  
fi


#Firing the consolidated query
								
hive -e "$q2;$q3;$q4;$q5;$q6;$q7"
stat4=$?
if [[ ! "$stat4" =~ "0" ]]; then
		 echo "------------ERROR : Failed in fetching COLUMNN NAMES--------------- " 
		exit 1
fi
echo "-----INFO: Data fetch COLUMN NAMES is successful `date`---------------------- " 




#Fetch the references into elements by using grep feature here references are i values which were taken in eariler steps

elements=$(grep -i "COLO" ${logfile} | egrep -o -E '[0-9]{1,5}' | tr '\n' ',' | sed 's/,$//') 
echo "elements are $elements"


#Take the count of references
                        
elements_count=$(grep -i "COLO" ${logfile} | egrep -o -E '[0-9]{1,5}' | wc -w)
echo "element count is $elements_count"


#Fetch the references into elements by using grep feature here references are i values which were taken in eariler steps

#Take the count of references
elements_col=$(grep -i "colt" ${logfile} | cut -f 1 -d '=' | egrep -o -E '[0-9]{1,10}' |  tr '\n' ',' | sed 's/,$//')				 
echo "elements of column_ref iss $elements_col"
elements_col_count=$(echo $elements_col | tr ',' ' '| wc -w)
echo "elements col_count is $elements_col_count"
elements_fil=$(grep -i "colf" ${logfile} | cut -f 1 -d '=' | egrep -o -E '[0-9]{1,10}' |  tr '\n' ',' | sed 's/,$//')
elements_fil_count=$(echo $elements_fil | tr ',' ' '| wc -w)
elements_grp=$(grep -i "colg" ${logfile} | cut -f 1 -d '=' | egrep -o -E '[0-9]{1,10}' |  tr '\n' ',' | sed 's/,$//')
elements_grp_count=$(echo $elements_grp | tr ',' ' '| wc -w)
elements_hav=$(grep -i "colh" ${logfile} | cut -f 1 -d '=' | egrep -o -E '[0-9]{1,10}' |  tr '\n' ',' | sed 's/,$//')
elements_hav_count=$(echo $elements_hav | tr ',' ' '| wc -w)
elements_ord=$(grep -i "colrde" ${logfile} | cut -f 1 -d '=' | egrep -o -E '[0-9]{1,10}' |  tr '\n' ',' | sed 's/,$//')
elements_ord_count=$(echo $elements_ord | tr ',' ' '| wc -w)


#Validating and tranforming Columid with names which are stored in arrays for column_format

if [[ ! -z $transform ]]
then
	for((i=0;i<$elements_count;i++));
	do
		a=$(($i+1))
        elements_instance=$(echo $elements | cut -f $a -d ',')
        col_instance=$(grep -i "colo_$elements_instance=" ${logfile}  | cut -f 2 -d '=') 
        extractor="${extractor/${IDS[$elements_instance]}/$col_instance}" ##Transformation step
        extractor="${extractor//|/,}"
    done
	
	for((i=0;i<$transform_count;i++))
    do
		g=$(($i+1))
        extract_delim=$(echo $extractor | cut -f $g -d '#')
        transform="${transform/${transform_array[$i]}/${format_array[$i]}?$extract_delim}" ##Transformation step
    done
#else
#	transform="NA"
fi
					  
transpose=$transpose','$transform
transpose=${transpose#?}
echo "$transpose"  

IFS='#' read -a resultarray<<<"$transpose" 
result_count=${#resultarray[@]}
                  
for((i=0;i<$result_count;i++))
do
	echo "p${resultarray[$i]}"
done
  

#Validating and tranforming Columid with names which are stored in arrays for column_reference

for((i=0;i<$elements_col_count;i++));
do
	b=$(($i+1))
    elements_instance1=$(echo $elements_col | cut -f $b -d ',')
    col_instance1=$(grep -i "colt_$elements_instance1=" ${logfile}  | cut -f 2 -d '=')
    echo "l${IDS_col[$elements_instance1]}?$col_instance1"
    coltransform_extract="${coltransform_extract/${IDS_col[$elements_instance1]}/$col_instance1}"
    coltransform_extract="${coltransform_extract//|/,}"
done


#Validating and tranforming Columid with names which are stored in arrays for filter
					
if [[ ! -z $filtertransform ]]
then
	for((i=0;i<$elements_fil_count;i++));
	do
		c=$(($i+1))
        elements_instance2=$(echo $elements_fil | cut -f $c -d ',')
        col_instance2=$(grep -i "colf_$elements_instance2=" ${logfile}  | cut -f 2 -d '=')
        filtertransform="${filtertransform/${IDS_filter[$elements_instance2]}/$col_instance2}"
        filtertransform="${filtertransform//|/,}"
		echo "$filtertransform"
	done
#else
	#filtertransform_extract="NA"
fi
	

#Validating and tranforming Columid with names which are stored in arrays for columnHaving
	
if [[ ! -z $colhavingtransform ]]
then
	for((i=0;i<$elements_hav_count;i++));
    do
		d=$(($i+1))
			elements_instance3=$(echo $elements_hav | cut -f $d -d ',')
            col_instance3=$(grep -i "colh_$elements_instance3=" ${logfile}  | cut -f 2 -d '=')
            colhavingtransform="${colhavingtransform/${IDS_hav[$elements_instance3]}/$col_instance3}"
            colhavingtransform="${colhavingtransform//|/,}"
			echo "$colhavingtransform"
	done
#else
	#colhavingtransform_extract="NA"
fi


#Validating and tranforming Columid with names which are stored in arrays for columnGroup

if [[ ! -z $colgrptransform ]]
then
	for((i=0;i<$elements_grp_count;i++));
    do
		e=$(($i+1))
        elements_instance4=$(echo $elements_grp | cut -f $e -d ',')
        col_instance4=$(grep -i "colg_$elements_instance4=" ${logfile}  | cut -f 2 -d '=')
        colgrptransform="${colgrptransform/${IDS_grp[$elements_instance4]}/$col_instance4}"
        colgrptransform="${colgrptransform//|/,}"
		echo "$colgrptransform_extract"
	done
#else
	#colgrptransform_extract="NA"
fi


#Validating and tranforming Columid with names which are stored in arrays for columnOrder
				
if [[ ! -z $colordtransform ]]
then
	for((i=0;i<$elements_ord_count;i++));
    do
		f=$(($i+1))
        elements_instance5=$(echo $elements_ord | cut -f $f -d ',')
        col_instance5=$(grep -i "colrde_$elements_instance5=" ${logfile}  | cut -f 2 -d '=')
        colordtransform="${colordtransform/${IDS_ord[$elements_instance5]}/$col_instance5}"
        colordtransform="${colordtransform//|/,}"
		echo "$colordtransform"
    done
#else
	#colordtransform_extract="NA"
fi

#Printing all the results which can be fetched in query builder path


echo "fltr_value?$filtertransform"
echo "column_hav?$colhavingtransform"
echo "column_ord=$colordtransform"
echo "column_group=$colgrptransform"



#The step properly aligns the column reference columns

colm_ref=$(grep 'colm_ref=' ${logfile} | cut -d '=' -f2 | sed 's/^[ \t]*//;s/[ \t]*$//')
echo "==========column ref in replace $colm_ref========="

IFS='|' read -a columnIdtoSearch<<<"$colm_ref"
updated_columnref=""
columnidcount=${#columnIdtoSearch[@]}

for((i=0;i<$columnidcount;i++))
do
	toreplace=$(grep -i "p${columnIdtoSearch[$i]}?" ${logfile} | cut -f 2 -d '?')
	if [[ -n "$toreplace" ]] 
	then
		updated_columnref+=$toreplace
		updated_columnref+="|"
	else
        toreplace=$(grep -i "l${columnIdtoSearch[$i]}?" ${logfile} | cut -f 2 -d '?')
		updated_columnref+=$toreplace
		updated_columnref+="|"
	fi
	
	final_columnref=$(echo $updated_columnref | sed 's/|/,/g') 
    final_columnref=$(echo $final_columnref | sed 's/,$//') 
done



echo "================================"
echo "final_columnref_names?$final_columnref"
echo "================================"
	
#################################################################################
### script_names : Query builder 
##This script builds the query and fired onto target table #
#################################################################################

selector=''
format=''
variable=''
tablename=''
filter=''
having=''
group=''
order=''
builder=''


#Fetching all the values for query building

selector=$(grep -i 'final_columnref_names?' ${logfile} | cut -f 2 -d '?')
echo "-----$selector------"
tablename=$(grep -i 'table_name=' ${logfile} | cut -f 2 -d '=')
echo "-----$tablename------"
filter=$(grep -i 'fltr_value?' ${logfile} | cut -f 2 -d '?')
echo "-----$filter------"
having=$(grep -i 'column_hav?' ${logfile} | cut -f 2 -d '?')
echo "-----$having------"
order=$(grep -i 'column_ord=' ${logfile} | cut -f 2 -d '=')
echo "-----$order------"
group=$(grep -i 'column_group=' ${logfile} | cut -f 2 -d '=')
echo "-----$group------"

#validation before firing query
if [[ ! -z $selector ]]
then
	selector="$selector"
else
	selector=''
fi

if [[ ! -z $filter ]]
then
	filter="where $filter"
else
	filter=''
fi

if [[ ! -z $group ]]
then
	group="group by $group"
else
	group=''
fi

if [[ ! -z $having ]]
then
	having="having $having"
else
	having=''
fi

if [[ ! -z $order ]]
then
	order="order by $order"
else
	order=''
fi


#Query build
if [[ ! "$file_type" =~ "delimiter" ]]
then
builder="use $SCHEMA_NAME;select $selector from $tablename $filter $group $having $order;"

echo "$builder" > "$LOG_DIR/$REPORT_NAME".hql

echo "----$builder------"
else
builder="use $SCHEMA_NAME;set hive.cli.print.header=true;select $selector from $tablename $filter $group $having $order;"

echo "$builder" > "$LOG_DIR/$REPORT_NAME".hql

echo "----$builder------"
fi


#Check condition for Aggregate operators with group by

if [[ "$selector" && "$format" && ! "$group" ]]
then
	echo "ERROR : Query incorrect"
else
	if [[ ! "$selector" && ! "$format" && "$group" ]]
	then
		echo "ERROR : Query incorrect"
	else
		#Fire query and store the result in CSV
		if [[ ! "$file_type" =~ "delimiter" ]]
		then
                        path="$path.txt"
			hive -f "$LOG_DIR/$REPORT_NAME".hql | sed 's/^WARN.*//g' | tr "\\t" "|" | sed 's/|//g' > $path;
			RET_VAL="${PIPESTATUS[0]}"
            echo "RET_VAL:$RET_VAL"
		else
                        path="$path.csv"
			hive -f "$LOG_DIR/$REPORT_NAME".hql | sed 's/^WARN.*//g' | tr "\\t" "$dlmtr_val" > $path;
			RET_VAL="${PIPESTATUS[0]}"
            echo "RET_VAL:$RET_VAL"
		fi
	fi
fi

#validating status
if [[ ! "$RET_VAL" =~ "0" ]]
then
status="FAIL"     
else
status="SUCCESS" 
fi
echo "INFO: fetched file details from target table successfully `date` " 

#fetching details to insert into EXTR_AUDIT table
RECORD_COUNT=$(cat "$path"| sed '/^\s*$/d' | wc -l)
RECORD_COUNT=$(($RECORD_COUNT-1))
end_date_time=$( date +'%Y-%m-%d %H:%M:%S')
echo "RECORD_COUNT:$RECORD_COUNT"
checkSum=$(md5sum "$path");
echo "checksum is :$checkSum"
echo "end time stamp:$end_date_time"
Audit_id="$RPT_ID$Audit_time"
Audit_id=$((Audit_id))
checksum=$(echo $checkSum | cut -f 1 -d ' ' )

#Inserting status to EXTR_AUDIT table
hive -e "use $SCHEMA_NAME;set hive.cli.print.header=true;INSERT into EXTR_AUDIT select '$Audit_id','$INTERFACE_NAME','$RPT_ID','$REPORT_NAME','$file_nm','$checksum','$RECORD_COUNT','$status',from_unixtime(unix_timestamp('$start_date_time','yyyy-MM-dd hh:mm:ss'),'yyyy-MM-dd HH:mm:ss'),from_unixtime(unix_timestamp('$end_date_time','yyyy-MM-dd hh:mm:ss'),'yyyy-MM-dd HH:mm:ss');"





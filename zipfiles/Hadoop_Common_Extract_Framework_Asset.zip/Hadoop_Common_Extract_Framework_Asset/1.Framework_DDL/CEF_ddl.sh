#!/bin/sh
# this script is to execute the HQL file containing the DDLs of below framework tables
# EXTR_INTERFACE
# EXTR_REPORT
# EXTR_TABLE
# EXTR_COLUMN
# EXTR_COLUMN_FORMAT
# EXTR_AUDIT

SCHEMA_NAME=$1
if [[ $# -ne 1 ]]                           ##checks whether two parameters are passed as input or not
 then
    echo "------ERROR : Expecting SCHEMA_NAME as parameter------- "
    exit 1
fi

hive -f CEF_ddl_staging.hql -hiveconf SCHEMA_NAME="$SCHEMA_NAME"
hive -f CEF_ddl_hive.hql -hiveconf SCHEMA_NAME="$SCHEMA_NAME"


#!/bin/sh
#This script is to add path and SCHEMA_NAME as parameters and execute hive load.

path=$1
schema_name=$2

if [[ $# -ne 2 ]]                           ##checks whether two parameters are passed as input or not
 then
    echo "------ERROR : Expecting two parameters PATH and SCHEMA_NAME------- "
    exit 1
fi

hive -f CEF_ingestion_staging.hql -hiveconf path="$path" -hiveconf SCHEMA_NAME="$schema_name"
hive -f CEF_ingestion_hive.hql -hiveconf SCHEMA_NAME="$schema_name"

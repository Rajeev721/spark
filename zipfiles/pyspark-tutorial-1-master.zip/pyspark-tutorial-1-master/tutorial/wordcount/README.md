* word_count.py

Word Count solution in PySpark: Note that input file is 
hard-coded: not a very good practice. The purpose is to 
show how to read files in Spark.

* word_count_ver2.py

I pass input file as a parameter.


````
best regards,
Mahmoud Parsian
````

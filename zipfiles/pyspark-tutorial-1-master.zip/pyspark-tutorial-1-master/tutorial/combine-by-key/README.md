Spark's combineByKey() Examples and Tutorial
============================================

* [Mean Calculation by combineByKey()](./spark-combineByKey.md)
* [Standard Deviation and Mean Calculation by combineByKey()](./standard_deviation_by_combineByKey.md)


[![Data Algorithms Book](https://github.com/mahmoudparsian/data-algorithms-book/blob/master/misc/data_algorithms_image.jpg)](http://shop.oreilly.com/product/0636920033950.do) 

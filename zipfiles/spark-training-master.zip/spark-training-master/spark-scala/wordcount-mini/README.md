# Spark Mini WordCount

This is the first RDD based WordCount implementation of the classic WordCount program. It is a minimalistic
version which expects the input data to be present in `alice` and will create the output at `alice-wordcount`.

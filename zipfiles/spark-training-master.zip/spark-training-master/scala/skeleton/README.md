# Spark WordCount

This is the first RDD based WordCount implementation of the classic WordCount program.

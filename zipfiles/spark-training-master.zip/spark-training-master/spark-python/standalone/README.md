# PySpark Standalone

This program demonstrates a stand-alone version of PySpark which does not rely on a "spark-submit". This is
specifically well suited for unittests and for running PySpark programs locally in an development environment.

# Running

    ./standalone.py

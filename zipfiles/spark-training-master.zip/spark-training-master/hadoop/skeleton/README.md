# Hadoop Skeleton

This project contains a skeleton of a Hadoop Map/Reduce application 

## Building

You can simply build the example with Maven via

        mvn install
        

## Running
        
The example also contains a small starter script. You can invoke the example via
        
        run.sh <args>
        
